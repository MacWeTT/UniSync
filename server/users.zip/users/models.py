from django.contrib.auth.models import AbstractUser
from django.db import models
from django.utils import timezone
import uuid


class User(AbstractUser):
    USER_TYPES = (
        ("student", "Student"),
        ("university", "University"),
    )

    user_type = models.CharField(max_length=10, choices=USER_TYPES, default="student")


class University(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name


class Student(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    name = models.CharField(max_length=100)

    bookmarks = models.ManyToManyField("projects.Project", related_name="bookmarked_by")

    def __str__(self):
        return self.name
