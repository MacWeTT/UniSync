from django.urls import path, include
from dj_rest_auth.registration.views import VerifyEmailView, ConfirmEmailView
from dj_rest_auth.views import PasswordResetConfirmView
from .views import GoogleLogin, UserRedirectView

urlpatterns = [
    path("", include("dj_rest_auth.urls")),
    path(
        "registration/account-confirm-email/<str:key>/",
        ConfirmEmailView.as_view(),
    ),
    path("registration/", include("dj_rest_auth.registration.urls")),
    path(
        "account-confirm-email/",
        VerifyEmailView.as_view(),
        name="account_email_verification_sent",
    ),
    path(
        "password/reset/confirm/<slug:uidb64>/<slug:token>/",
        PasswordResetConfirmView.as_view(),
        name="password_reset_confirm",
    ),
    path("~redirect/", view=UserRedirectView.as_view(), name="redirect"),
]

urlpatterns += [
    path("google", GoogleLogin.as_view(), name="google_login"),
]
